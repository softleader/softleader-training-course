package tw.com.softleader.ireport.model;

import net.sf.jasperreports.engine.JRDataSource;

public class InsuCompany {
	
	private String companyName;
	
	private JRDataSource policyList1;
	
	private JRDataSource policyList2;

	public InsuCompany(String companyName, JRDataSource policyList1, JRDataSource policyList2) {
		super();
		this.companyName = companyName;
		this.policyList1 = policyList1;
		this.policyList2 = policyList2;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public JRDataSource getPolicyList1() {
		return policyList1;
	}

	public void setPolicyList1(JRDataSource policyList1) {
		this.policyList1 = policyList1;
	}

	public JRDataSource getPolicyList2() {
		return policyList2;
	}

	public void setPolicyList2(JRDataSource policyList2) {
		this.policyList2 = policyList2;
	}
	
}
