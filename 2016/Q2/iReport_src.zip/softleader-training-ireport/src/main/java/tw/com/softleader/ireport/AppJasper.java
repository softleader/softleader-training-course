package tw.com.softleader.ireport;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import tw.com.softleader.commons.collect.Lists;
import tw.com.softleader.ireport.model.InsuCompany;
import tw.com.softleader.ireport.model.InsuData;
import tw.com.softleader.ireport.model.InsuPolicy;
import tw.com.softleader.report.jasper.utils.JasperReportUtils;

public class AppJasper {

	public static void main(String[] args) throws IOException, JRException {
		
		// 讀入jrxml
		InputStream jrxml3 = getResourceFromClassPath("jrxml/report3.jrxml");
		InputStream jrxml3_sub1 = getResourceFromClassPath("jrxml/report3_sub1.jrxml");
		InputStream jrxml3_sub1_1 = getResourceFromClassPath("jrxml/report3_sub1_1.jrxml");
		InputStream jrxml3_sub1_2 = getResourceFromClassPath("jrxml/report3_sub1_2.jrxml");
		
		// 將jrxml轉為JasperDesign
		JasperDesign design3 = JRXmlLoader.load(jrxml3);
		JasperDesign design3_sub1 = JRXmlLoader.load(jrxml3_sub1);
		JasperDesign design3_sub1_1 = JRXmlLoader.load(jrxml3_sub1_1);
		JasperDesign design3_sub1_2 = JRXmlLoader.load(jrxml3_sub1_2);
		
		// 將JasperDesign轉為JasperReport
		JasperReport report3 = JasperCompileManager.compileReport(design3);
		JasperReport report3_sub1 = JasperCompileManager.compileReport(design3_sub1);
		JasperReport report3_sub1_1 = JasperCompileManager.compileReport(design3_sub1_1);
		JasperReport report3_sub1_2 = JasperCompileManager.compileReport(design3_sub1_2);
		
		// 處理parameter與datasource
		Map<String, Object> report3_parameters = new HashMap<>();
		report3_parameters.put("BARCODE", "00005THQ11344");
		report3_parameters.put("SUBREPORT", report3_sub1);
		report3_parameters.put("SUBREPORT_1", report3_sub1_1);
		report3_parameters.put("SUBREPORT_2", report3_sub1_2);
		
		List<InsuData> report3_data = generateTestData();
		JRBeanCollectionDataSource report3_datasource = new JRBeanCollectionDataSource(report3_data);
		
		// 將JasperReport轉為JasperPrint(parameter與datasource於這一步塞入)
		JasperPrint print3 = JasperFillManager.fillReport(report3, report3_parameters, report3_datasource);
		
		// 預覽
		JasperViewer.viewReport(print3);
		
		// 輸出為pdf
		// JasperExportManager.exportReportToPdfStream(print3, new FileOutputStream(new File("TestReport.pdf")));
	}
	
	private static List<InsuData> generateTestData() {
		return Lists.newArrayList(
				new InsuData("張OO", "00560105", "A123456789", 
						JasperReportUtils.toJRDataSource(Lists.newArrayList(
								new InsuCompany("安泰人壽", 
									JasperReportUtils.toJRDataSource(Lists.newArrayList(
										new InsuPolicy("A1000000000001"),
										new InsuPolicy("A1000000000002"),
										new InsuPolicy("A1000000000003"))),
									JasperReportUtils.toJRDataSource(Lists.newArrayList(
										new InsuPolicy("A1000000000004"),
										new InsuPolicy("A1000000000005"),
										new InsuPolicy("A1000000000006"),
										new InsuPolicy("A1000000000007"),
										new InsuPolicy("A1000000000008")))
								),
								new InsuCompany("南山人壽", 
									JasperReportUtils.toJRDataSource(Lists.newArrayList(
										new InsuPolicy("N1000000000001"),
										new InsuPolicy("N1000000000002"),
										new InsuPolicy("N1000000000003"),
										new InsuPolicy("N1000000000004"))),
									JasperReportUtils.toJRDataSource(Lists.newArrayList(
										new InsuPolicy("N1000000000005"),
										new InsuPolicy("N1000000000006")))
								)
						))
				),
				new InsuData("王XX", "00560105", "A123456789", 
						JasperReportUtils.toJRDataSource(Lists.newArrayList(
								new InsuCompany("安泰人壽", 
									JasperReportUtils.toJRDataSource(Lists.newArrayList(
										new InsuPolicy("A2000000000001"),
										new InsuPolicy("A2000000000003"),
										new InsuPolicy("A2000000000004"))),
									JasperReportUtils.toJRDataSource(Lists.newArrayList(
										new InsuPolicy("A2000000000005"),
										new InsuPolicy("A2000000000006"),
										new InsuPolicy("A2000000000007"),
										new InsuPolicy("A2000000000008")))
								)
						))
				),
                new InsuData("李XX", "00560105", "A123456789", 
                    JasperReportUtils.toJRDataSource(Lists.newArrayList(
                            new InsuCompany("富邦人壽", 
                                JasperReportUtils.toJRDataSource(Lists.newArrayList(
                                    new InsuPolicy("F3000000000001"),
                                    new InsuPolicy("F3000000000003"),
                                    new InsuPolicy("F3000000000004"))),
                                JasperReportUtils.toJRDataSource(Lists.newArrayList(
                                    new InsuPolicy("F3000000000005"),
                                    new InsuPolicy("F3000000000006"),
                                    new InsuPolicy("F3000000000007"),
                                    new InsuPolicy("F3000000000008")))
                            ),
                            new InsuCompany("台銀人壽", 
                                JasperReportUtils.toJRDataSource(Lists.newArrayList(
                                    new InsuPolicy("T3000000000001"),
                                    new InsuPolicy("T3000000000003"),
                                    new InsuPolicy("T3000000000004"))),
                                JasperReportUtils.toJRDataSource(Lists.newArrayList(
                                    new InsuPolicy("T3000000000005"),
                                    new InsuPolicy("T3000000000006"),
                                    new InsuPolicy("T3000000000007"),
                                    new InsuPolicy("T3000000000008")))
                            )
                    ))
            )
		);
	}
	
	public static InputStream getResourceFromClassPath(String str) throws IOException {
	  return AppJasper.class.getClassLoader().getResourceAsStream(str);
	}
	
}
