package tw.com.softleader.ireport.model;

public class InsuPolicy {
	
	private String insuNo;

	public InsuPolicy(String insuNo) {
		super();
		this.insuNo = insuNo;
	}

	public String getInsuNo() {
		return insuNo;
	}

	public void setInsuNo(String insuNo) {
		this.insuNo = insuNo;
	}
	
}
