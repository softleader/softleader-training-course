package tw.com.softleader.ireport.model;

import net.sf.jasperreports.engine.JRDataSource;

public class InsuData {
	
	private String name;
	
	private String birthday;
	
	private String idNo;
	
	private JRDataSource companyList;

	public InsuData(String name, String birthday, String idNo, JRDataSource companyList) {
		super();
		this.name = name;
		this.birthday = birthday;
		this.idNo = idNo;
		this.companyList = companyList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getIdNo() {
		return idNo;
	}

	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}

	public JRDataSource getCompanyList() {
		return companyList;
	}

	public void setCompanyList(JRDataSource companyList) {
		this.companyList = companyList;
	}

}
