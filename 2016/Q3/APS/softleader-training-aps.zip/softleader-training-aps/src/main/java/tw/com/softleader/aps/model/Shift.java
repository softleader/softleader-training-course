package tw.com.softleader.aps.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import lombok.Getter;

/**
 * 這是一個用來表示班表的物件
 * 正是情況中，這班表物件應該要再紀錄資源(工程師)作為key
 * 因為每一項資源的班表不見得相同
 *
 * @author Rhys
 */
@Getter
public class Shift {

	private final LocalDate date;
	private final LocalTime startTime;
	private final LocalTime finishTime;
	private final LocalDateTime startDateTime;
	private final LocalDateTime finishDateTime;

	public Shift(final LocalDate date, final LocalTime startTime, final LocalTime finishTime) {
		super();
		this.date = date;
		this.startTime = startTime;
		this.finishTime = finishTime;
		this.startDateTime = date.atTime(startTime);
		this.finishDateTime = date.atTime(finishTime);
	}

}
