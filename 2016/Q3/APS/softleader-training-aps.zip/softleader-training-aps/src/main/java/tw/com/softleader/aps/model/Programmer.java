package tw.com.softleader.aps.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 這是一個用來表示工程師的物件
 * 工程師(資源)最重要的參數是他做何種工作，以及處理量為多少
 * 這些參數將會在規劃的時候列入參考
 *
 * @author Rhys
 */
@Getter
@Setter
@ToString
public class Programmer {

	// 名字
	private final String name;

	// 工作速度(每小時處理量)
	private int capacity;

	// 工作類型
	private JobType jobType;

	public Programmer(final String name, final int capacity, final JobType jobType) {
		super();
		this.name = name;
		this.capacity = capacity;
		this.jobType = jobType;
	}

	public String getName() {
		return name;
	}

	/**
	 * 工程師進行工作
	 * @param job
	 * @return 花費的時間(分鐘)
	 */
	public final long work(final Job job) {
		if (job.getType().equals(jobType)) {
			return (long)(((double)job.getQuantity()) / ((double)capacity) * 60);
		} else {
			throw new RuntimeException(name + ": 我無法執行這個工作類型. JobType:" + job);
		}
	}

}
