package tw.com.softleader.aps.model;

import java.time.LocalTime;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 批次產生班表用的規則
 *
 * @author Rhys
 */
@Getter
@AllArgsConstructor
public class ShiftPattern {

	private final LocalTime startTime;
	private final LocalTime finishTime;

}
