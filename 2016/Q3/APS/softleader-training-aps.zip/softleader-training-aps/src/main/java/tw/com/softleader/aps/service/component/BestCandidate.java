package tw.com.softleader.aps.service.component;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.Optional;
import java.util.function.Function;

import tw.com.softleader.aps.model.ApsCandidate;
import tw.com.softleader.aps.model.ApsResult;
import tw.com.softleader.aps.model.Operation;

/**
 * 決定最佳候選人的方法
 *
 * @author Rhys
 */
public class BestCandidate implements Comparator<ApsCandidate> {

	private Comparator<ApsCandidate> comparing;

	public BestCandidate(final ApsResult apsResult) {
		this.comparing = Comparator
				.comparing(byStartTime())
				.thenComparing(bySameProject(apsResult))
				.thenComparing(byWorkTime());
	}

	// 根據系統建議的最早開始時間
	private Function<ApsCandidate, LocalDateTime> byStartTime() {
		return ApsCandidate::getSuggestStartTime;
	}

	// 根據此工作被此工程師執行的時間長
	private Function<ApsCandidate, Long> byWorkTime() {
		return ApsCandidate::getWorkMinute;
	}

	// 工作優先度, 同一位工程師, 最好同個專案的工作連著做, 若沒辦法則優先挑沒有前置工作的來做
	private Function<ApsCandidate, Integer> bySameProject(final ApsResult apsResult) {
		return c -> {
			final Optional<Operation> lastOperation = apsResult.getLastOperation(c.getProgrammer());
			if (lastOperation.isPresent()) {
				final String thisPrjectName = c.getJob().getProjectName();
				final String projectName = lastOperation.get().getJob().getProjectName();
				return thisPrjectName.equals(projectName) ? 50 : 200;
			}
			return 100;
		};
	}

	@Override
	public int compare(final ApsCandidate o1, final ApsCandidate o2) {
		return comparing.compare(o1, o2);
	}

}
