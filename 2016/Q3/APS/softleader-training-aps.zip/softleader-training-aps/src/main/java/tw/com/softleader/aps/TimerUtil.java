package tw.com.softleader.aps;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@SuppressWarnings("serial")
public class TimerUtil extends HashMap<String, Integer> {
	
	public <T> T apply(Callable<T> task, String key) {
		int milli;
		if (this.containsKey(key)) {
			milli = this.get(key);
		} else {
			milli = 0;
		}
		
		final LocalDateTime t1 = LocalDateTime.now();
		T result;
		try {
			result =  task.call();
		} catch (Exception e) {
			result = null;
			throw new RuntimeException(e);
		} finally {
			final Duration d = Duration.between(t1, LocalDateTime.now());
			milli += d.toMillis();
			TimerUtil.synchronizedPut(this, key, milli);
		}
		return result;
		
	}
	
	private static ExecutorService executor = Executors.newSingleThreadExecutor();
	public static void synchronizedPut(TimerUtil timer, String key, Integer value) {
		executor.submit(() -> timer.put(key, value));
	}
	
}
