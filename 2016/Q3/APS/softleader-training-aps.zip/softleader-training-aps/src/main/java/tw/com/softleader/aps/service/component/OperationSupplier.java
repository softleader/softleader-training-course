package tw.com.softleader.aps.service.component;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import tw.com.softleader.aps.exception.OutOfShiftException;
import tw.com.softleader.aps.model.ApsCandidate;
import tw.com.softleader.aps.model.Operation;
import tw.com.softleader.aps.model.Shift;
import tw.com.softleader.commons.collect.Lists;

/**
 * 將候選任務轉換為可以執行的任務
 * 過程中需要依照班表來進行切割
 * 例: 若一個任務計算出的工時會超過下班時間, 則應該要在隔天早上繼續進行
 *
 * @author Rhys
 */
public class OperationSupplier {

	private ApsCandidate bestSolution;
	private LinkedList<Shift> shifts;

	public OperationSupplier(final ApsCandidate bestSolution, final LinkedList<Shift> shifts) {
		this.bestSolution = bestSolution;
		this.shifts = shifts;
	}

	public List<Operation> get() throws OutOfShiftException {
		final List<Operation> result = Lists.newArrayList();

		// 完成百分比(因為可能會將一個工作切成多個班表進行)
		BigDecimal percent = BigDecimal.ONE.setScale(2);
		// 剩餘的工時(理由同上, 用來計算還需要多少時間才能完成這工作)
		long lastWorkMinute = bestSolution.getWorkMinute();
		// 時間指針
		LocalDateTime currentTime = bestSolution.getSuggestStartTime();
		// 班表指針
		Shift shift = getNearestShift(currentTime);

		// 只要還有剩餘的工時就要產生Operation
		while(lastWorkMinute > 0) {
			// 推估結束時間
			final LocalDateTime finishTime = currentTime.plusMinutes(lastWorkMinute);

			if(shift.getFinishDateTime().isBefore(finishTime)) {
				// 若預測結束時間超出此班表, 則要加一班, 此次Operation結束時間則為此班結束時間
				final Operation operation = new Operation(bestSolution.programmer, bestSolution.job, currentTime, shift.getFinishDateTime());
				operation.setPercent(BigDecimal.valueOf(((double)operation.getWorkMinute()) / ((double)bestSolution.getWorkMinute())));
				// 計算剩餘的工作百分比
				percent = percent.subtract(operation.getPercent());

				// 若切出來的第一班剛好落在班表結束時間(執行時間為0), 則直接換班, 這班因為根本沒工作, 不採計
				if (operation.getWorkMinute() > 0) {
					result.add(operation);
				}

				// 計算剩餘的工作時間長度
				lastWorkMinute = Duration.between(shift.getFinishDateTime(), finishTime).toMinutes();
				// 取得下一個班表, 與時間指針
				final int nextShiftIdx = shifts.indexOf(shift) + 1;
				if (nextShiftIdx < shifts.size()) {
					shift = shifts.get(nextShiftIdx);
					currentTime = shift.getStartDateTime();
				} else {
					// 若沒有班表可以取, 則需要讓主流程知道
					throw new OutOfShiftException();
				}
			} else {
				// 若預測結束時間在班表內, 直接套用
				final Operation operation = new Operation(bestSolution.programmer, bestSolution.job, currentTime, finishTime);
				operation.setPercent(percent);
				result.add(operation);
				lastWorkMinute = 0;
			}

		}

		return result;
	}

	// 取得當前, 或是下一個班表
	private Shift getNearestShift(final LocalDateTime currentTime) throws OutOfShiftException {
		return shifts.stream()
				.filter(s -> !s.getFinishDateTime().isBefore(currentTime))
				.min(Comparator.comparing(Shift::getStartDateTime))
				.orElseThrow(() -> new OutOfShiftException());
	}

}
