package tw.com.softleader.aps.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.LinkedList;
import java.util.List;

import tw.com.softleader.aps.model.Shift;
import tw.com.softleader.aps.model.ShiftPattern;
import tw.com.softleader.commons.collect.Lists;

public class ShiftService {

	private static final List<ShiftPattern> shiftPatterns = Lists.newArrayList(
			new ShiftPattern(LocalTime.parse("09:30"), LocalTime.parse("12:30")),
			new ShiftPattern(LocalTime.parse("13:30"), LocalTime.parse("18:30"))
		);

	/** 產生從startTime開始往未來N周的班表 */
	public LinkedList<Shift> getShifts(final LocalDate startDate, final int weeks) {
		// 在處理Operation的時候, 常會有需要移動班表的情況, 以LinkedList宣告可以有利於這個需求
		final LinkedList<Shift> shifts = Lists.newLinkedList();
		// 進行排程規劃時, 通常不會把所有任務一口氣排完, 而會限定在一個時間段內
		final LocalDate finishDate = startDate.plusWeeks(weeks);

		// 日期指針, 從起始日到結束日一直產生班表, 僅示範, 不考慮假日
		LocalDate currentDate = startDate;
		while(!finishDate.isBefore(currentDate)) {
			for (final ShiftPattern pattern : shiftPatterns) {
				// 由於上班時間不會跨日, 起始時間與結束時間一定是同一天, 因此不用特別處理換日問題
				shifts.add(new Shift(currentDate, pattern.getStartTime(), pattern.getFinishTime()));
			}
			currentDate = currentDate.plusDays(1);
		}

		return shifts;
	}

}
