package tw.com.softleader.aps.model;

import lombok.Getter;
import lombok.Setter;

/**
 * 這是一個工作的物件，用來表示該工作的類型、工作量、前一份工作
 * 本Job設計的較單純，正式情況下，previousJob有可能為多
 *
 * @author Rhys
 */
@Getter
@Setter
public class Job {

	// 工作類型
	private final JobType type;

	// 工作名稱
	private final String name;

	// 工作量
	private final int quantity;

	// 前一個工作
	private final Job previousJob;

	public String getProjectName() {
		return name.split("-")[0];
	}

	public Job(final JobType type, final String name, final int quantity) {
		this(type, name, quantity, null);
	}

	public Job(final JobType type, final String name, final int quantity, final Job previousJob) {
		this.type = type;
		this.name = name;
		this.quantity = quantity;
		this.previousJob = previousJob;
	}

	@Override
	public String toString() {
		return name + "[" + type + "] qty:" + quantity;
	}

}
