package tw.com.softleader.aps.service;

import static java.util.stream.Collectors.groupingBy;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import tw.com.softleader.aps.model.Operation;

public class OperationService {

	private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	/**
	 * 依日期印出工作計畫
	 * @param allOperations
	 */
	public static void print(final Collection<Operation> allOperations) {
		final Map<LocalDate, List<Operation>> operationTimeGrid = allOperations.stream().collect(groupingBy(o -> o.getStartedTime().toLocalDate()));

		new TreeMap<>(operationTimeGrid).forEach((date, operations) -> {
			operations.sort(Comparator.comparing(o -> ((Operation) o).getProgrammer().getName()).thenComparing(o -> ((Operation) o).getStartedTime()));
			System.out.println(formatter.format(date));
			operations.forEach(operation -> System.out.println("\t" + operation));
			System.out.println();
		});

	}

}
