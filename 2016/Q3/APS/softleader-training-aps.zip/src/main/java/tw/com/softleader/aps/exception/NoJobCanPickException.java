package tw.com.softleader.aps.exception;

@SuppressWarnings("serial")
public class NoJobCanPickException extends RuntimeException {

}
