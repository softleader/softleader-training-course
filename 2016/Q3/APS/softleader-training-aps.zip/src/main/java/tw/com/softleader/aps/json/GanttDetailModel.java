package tw.com.softleader.aps.json;

import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import tw.com.softleader.aps.model.Operation;

@Getter
@Setter
public class GanttDetailModel {

	@JsonProperty("from")
	private String from;

	@JsonProperty("to")
	private String to;

	@JsonProperty("label")
	private String label;

	@JsonProperty("customClass")
	private String customClass;

	@JsonProperty("fromTime")
	private String fromTime;

	@JsonProperty("toTime")
	private String toTime;

	@JsonProperty("jobType")
	private String jobType;

	@JsonProperty("programmer")
	private String programmer;

	@JsonIgnore
	private static DateTimeFormatter format = DateTimeFormatter.ofPattern("HH:mm");
	public GanttDetailModel(final Operation operation) {
		this.from = "/Date(" + operation.getStartedTime().toInstant(ZoneOffset.ofHours(8)).toEpochMilli() + ")/";
		this.fromTime = operation.getStartedTime().format(format);
		this.to = "/Date(" + operation.getFinishedTime().toInstant(ZoneOffset.ofHours(8)).toEpochMilli() + ")/";
		this.toTime = operation.getFinishedTime().format(format);
		this.label = operation.getJob().getName();
		this.jobType = operation.getJob().getType().toString();
		this.programmer = operation.getProgrammer().getName();

		final int color = Integer.valueOf(operation.getJob().getProjectName().substring(3)) % 13;
		this.customClass = "gantt-" + color;
	}

}
