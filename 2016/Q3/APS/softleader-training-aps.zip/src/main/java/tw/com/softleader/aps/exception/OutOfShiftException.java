package tw.com.softleader.aps.exception;

@SuppressWarnings("serial")
public class OutOfShiftException extends Exception {

}
