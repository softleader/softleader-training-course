package tw.com.softleader.aps.model;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import com.google.common.collect.Lists;

/**
 * 此物件為Job乘上Programmer的矩陣
 * 由於本示範專案的資料結構複雜度比較低，因此只乘到二維為止
 * 根據實際狀況可能還需要依據資源類型作grouping
 *
 * @author Rhys
 */
public class ApsMatrix implements List<ApsCandidate> {

	private final List<ApsCandidate> matrix;

	public ApsMatrix(final List<Job> jobs, final List<Programmer> programmers) {
		final List<ApsCandidate> matrix = Lists.newArrayList();

		// 乘開Job與Programmer
		for (final Programmer programmer : programmers) {
			for (final Job job : jobs) {
				// 把不能做的工作的可能性篩選掉
				if (programmer.getJobType().equals(job.getType())) {
					matrix.add(new ApsCandidate(job, programmer));
				}
			}
		}

		this.matrix = matrix;
	}

	// 根據Job刪除候選
	public void removeJob(final Job job) {
		matrix.removeIf(c -> c.job == job);
	}

	// 根據候選刪除所有關聯
	public void removeCandidate(final ApsCandidate candidate) {
		matrix.removeIf(c -> c == candidate);
		matrix.removeIf(c -> c.getProgrammer() == candidate.getProgrammer());
	}

	@Override
	public int size() {
		return matrix.size();
	}

	@Override
	public boolean isEmpty() {
		return matrix.isEmpty();
	}

	@Override
	public boolean contains(final Object o) {
		return matrix.contains(o);
	}

	@Override
	public Iterator<ApsCandidate> iterator() {
		return matrix.iterator();
	}

	@Override
	public Object[] toArray() {
		return matrix.toArray();
	}

	@Override
	public <T> T[] toArray(final T[] a) {
		return matrix.toArray(a);
	}

	@Override
	public boolean add(final ApsCandidate e) {
		return matrix.add(e);
	}

	@Override
	public boolean remove(final Object o) {
		return matrix.remove(o);
	}

	@Override
	public boolean containsAll(final Collection<?> c) {
		return matrix.containsAll(c);
	}

	@Override
	public boolean addAll(final Collection<? extends ApsCandidate> c) {
		return matrix.addAll(c);
	}

	@Override
	public boolean addAll(final int index, final Collection<? extends ApsCandidate> c) {
		return matrix.addAll(index, c);
	}

	@Override
	public boolean removeAll(final Collection<?> c) {
		return matrix.removeAll(c);
	}

	@Override
	public boolean retainAll(final Collection<?> c) {
		return matrix.retainAll(c);
	}

	@Override
	public void clear() {
		matrix.clear();
	}

	@Override
	public boolean equals(final Object o) {
		return matrix.equals(o);
	}

	@Override
	public int hashCode() {
		return matrix.hashCode();
	}

	@Override
	public ApsCandidate get(final int index) {
		return matrix.get(index);
	}

	@Override
	public ApsCandidate set(final int index, final ApsCandidate element) {
		return matrix.set(index, element);
	}

	@Override
	public void add(final int index, final ApsCandidate element) {
		matrix.add(index, element);
	}


	@Override
	public ApsCandidate remove(final int index) {
		return matrix.remove(index);
	}

	@Override
	public int indexOf(final Object o) {
		return matrix.indexOf(o);
	}

	@Override
	public int lastIndexOf(final Object o) {
		return matrix.lastIndexOf(o);
	}

	@Override
	public ListIterator<ApsCandidate> listIterator() {
		return matrix.listIterator();
	}

	@Override
	public ListIterator<ApsCandidate> listIterator(final int index) {
		return matrix.listIterator(index);
	}

	@Override
	public List<ApsCandidate> subList(final int fromIndex, final int toIndex) {
		return matrix.subList(fromIndex, toIndex);
	}

}
