package tw.com.softleader.aps.model;

import java.time.LocalDateTime;

import lombok.Getter;

/**
 * 排程候選
 *
 * @author Rhys
 */
@Getter
public class ApsCandidate {

	public final Job job;
	public final Programmer programmer;
	public final long workMinute;

	public ApsCandidate(final Job job, final Programmer programmer) {
		super();
		this.job = job;
		this.programmer = programmer;
		this.workMinute = programmer.work(job);
	}

	public LocalDateTime suggestStartTime;

	@Override
	public String toString() {
		return "(" + programmer.getName() + ")" + job.toString();
	}
}
