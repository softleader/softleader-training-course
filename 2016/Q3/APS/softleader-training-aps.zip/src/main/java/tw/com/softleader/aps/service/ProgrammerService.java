package tw.com.softleader.aps.service;

import com.google.common.collect.Lists;
import tw.com.softleader.aps.model.JobType;
import tw.com.softleader.aps.model.Programmer;

import java.util.List;

/**
 * 隨機產生工程師用的Service
 * @author Rhys
 */
public class ProgrammerService {

	private static List<Programmer> programmers;
	private static String[] names = {"Gary", "Jack", "John", "Naomi", "Matt", "Stacey", "David",
			"Sam", "Ken", "Ray", "Vicky", "Chris", "French", "Joshua", "Toba", "Frank", "Sunny", "Winni", "Ellie",
			"Bruce", "Joyce", "Benny", "Steven", "Van", "Zoe", "Glen", "Jerry", "Rhys", "Tim", "Willy", "Hilda",
			"Dennis", "Meta", "Irene", "Ines", "Leo", "Ryan", "Thomas", "Robert", "Karissa", "Tony", "Archer", "Sophie",
			"Peggy"};

	static {
		programmers = Lists.newArrayList();

		// 產生工程師
		for (char i = 0; i < names.length; i++) {
			final JobType[] jobTypes = JobType.values();
			final JobType jobType = jobTypes[(int) (Math.random() * jobTypes.length)];
			final int capacity = (int) (Math.random() * 6) + 3;
			programmers.add(new Programmer(names[i], capacity, jobType));
		}
	}

	/**
	 * 取得所有工程師
	 *
	 * @return
	 */
	public List<Programmer> getAllProgrammers() {
		return programmers;
	}

}
