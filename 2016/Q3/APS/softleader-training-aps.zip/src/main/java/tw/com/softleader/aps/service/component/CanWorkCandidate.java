package tw.com.softleader.aps.service.component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import tw.com.softleader.aps.model.ApsCandidate;
import tw.com.softleader.aps.model.ApsResult;
import tw.com.softleader.aps.model.Job;
import tw.com.softleader.aps.model.Operation;

/**
 * 判斷一個候選人是不是可以進入這一輪的比較
 *
 * @author Rhys
 */
public class CanWorkCandidate implements Predicate<ApsCandidate> {

	private final ApsResult apsResult;
	private final List<Operation> operations;
	private final Map<Job, List<Operation>> jobOperations;

	public CanWorkCandidate(final ApsResult apsResult) {
		this.apsResult = apsResult;
		this.operations = apsResult.getOperations();
		this.jobOperations = jobOperations(this.operations);
	}

	/**
	 * 取得可以開始排的候選任務
	 */
	@Override
	public boolean test(final ApsCandidate candidate) {
		// 取得可排的時間
		final LocalDateTime suggestStartTime = new CanStartTimeSupplier(candidate, jobOperations, apsResult).get();
		candidate.suggestStartTime = suggestStartTime;

		// 判斷是否有可排的時間
		if (suggestStartTime == null) {
			return false;
		}

		// 判斷前一分工作
		if (!hasNoPreviousJob(candidate) && !previousJobDone(candidate, suggestStartTime)) {
			return false;
		}

		return true;
	}

	// 無前一份工作
	private boolean hasNoPreviousJob(final ApsCandidate candidate) {
		return candidate.job.getPreviousJob() == null;
	}

	// 前一份工作已經完成
	private boolean previousJobDone(final ApsCandidate candidate, final LocalDateTime suggestStartTime) {
		BigDecimal percent = BigDecimal.ZERO;

		// 計算在當前時間前一份工作已經完成的比例
		if (jobOperations.containsKey(candidate.job.getPreviousJob())) {
			final List<Operation> preJobOperations = jobOperations.get(candidate.job.getPreviousJob());
			for (final Operation operation : preJobOperations) {
				// 由於會切班表的緣故, 必須要判斷完成100%才能進行下一份工作
				if (!operation.getFinishedTime().isAfter(suggestStartTime)) {
					percent = percent.add(operation.getPercent());
				}
			}
		}

		// 如果比例為100%以上則代表已完成
		return percent.doubleValue() >= 1;
	}

	// 將任務以工作分組
	private Map<Job, List<Operation>> jobOperations(final List<Operation> operations) {
		return operations.stream().collect(Collectors.groupingBy(Operation::getJob));
	}

}
