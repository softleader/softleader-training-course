package tw.com.softleader.aps;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import lombok.extern.slf4j.Slf4j;

@SuppressWarnings("serial")
@Slf4j
public class ApsTimer extends HashMap<String, Integer> {

	public <T> T apply(Callable<T> task, String key) {
		int milli;
		if (this.containsKey(key)) {
			milli = this.get(key);
		} else {
			milli = 0;
		}

		final LocalDateTime t1 = LocalDateTime.now();
		T result;
		try {
			result =  task.call();
		} catch (final Exception e) {
			result = null;
			throw new RuntimeException(e);
		} finally {
			final Duration d = Duration.between(t1, LocalDateTime.now());
			milli += d.toMillis();
			this.synchronizedPut(key, milli);
		}
		return result;

	}

	public void apply(Runnable task, String key) {
		int milli;
		if (this.containsKey(key)) {
			milli = this.get(key);
		} else {
			milli = 0;
		}

		final LocalDateTime t1 = LocalDateTime.now();
		try {
			task.run();
		} catch (final Exception e) {
			throw new RuntimeException(e);
		} finally {
			final Duration d = Duration.between(t1, LocalDateTime.now());
			milli += d.toMillis();
			this.synchronizedPut(key, milli);
		}
	}

	private ExecutorService executor = Executors.newSingleThreadExecutor();
	/**
	 * 這個Timer可以同時記錄好幾個時間段
	 * 但是為了避免紀錄時間的Map使用synchronized而造成主流成阻塞
	 * 這邊使用SingleThreadExecutor來將計算完的時間放入
	 *
	 * @param key 功能名稱
	 * @param value 毫秒數
	 */
	public void synchronizedPut(String key, Integer value) {
		executor.submit(() -> this.put(key, value));
	}

	public void show() {
		executor.shutdown();
		while(!executor.isShutdown()) {}
		this.forEach((k, v) -> log.info("[{}] used {} ms", k, v));
	}

}
