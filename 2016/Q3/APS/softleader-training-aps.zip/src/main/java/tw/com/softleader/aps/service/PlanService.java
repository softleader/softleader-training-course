package tw.com.softleader.aps.service;

import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import tw.com.softleader.aps.ApsTimer;
import tw.com.softleader.aps.exception.OutOfShiftException;
import tw.com.softleader.aps.model.*;
import tw.com.softleader.aps.service.component.BestCandidate;
import tw.com.softleader.aps.service.component.CanWorkCandidate;
import tw.com.softleader.aps.service.component.OperationSupplier;

import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

/**
 * 規劃排程
 *
 * @author Rhys
 */
@Slf4j
public class PlanService {

	private ShiftService shiftService = new ShiftService();

	public ApsResult plan(final LocalDateTime startTime, final List<Programmer> programmers, final List<Job> jobs) {
		// ===資料準備===
		// 用來統計功能執行時間的Timer
		final ApsTimer timer = new ApsTimer();
		// 描述工程師與工作執行的結果
		final List<Operation> planedResult = Lists.newArrayList();
		// 所有工程師與工作相乘的可能性
		final ApsMatrix matrix = timer.apply(() -> new ApsMatrix(jobs, programmers), "new ApsMatrix");
		// 工程師上班的描述(班表)
		final LinkedList<Shift> shifts = shiftService.getShifts(startTime.toLocalDate(), 12); // 只計算未來一周的班表
		// 所有運算過程中會用到的統計資訊
		final ApsResult apsResult = new ApsResult(timer, startTime, matrix, matrix.size(), shifts, planedResult);

		// 只要還有可能性就一直排下去, 根據邏輯的複雜度, 將會有無限迴圈的可能, 可能需要在此排除這個問題
		while(!matrix.isEmpty()) {
			// 可排的工作判斷模組
			final CanWorkCandidate canWorkCandidate = new CanWorkCandidate(apsResult);

			// 最佳的候選人判斷模組
			final BestCandidate bestCandidate = new BestCandidate(apsResult);

			// 需要在最後從可能性中移除的項目
			final List<ApsCandidate> toRemoveCandidates = Lists.newArrayList();
			final List<Job> toRemoveJobs = Lists.newArrayList();

			// 開始進行所有可能性的篩選
			final Optional<ApsCandidate> bestSolution = timer.apply(() -> {
				return matrix.stream()
					.filter(canWorkCandidate) // 候選人篩選
					.min(bestCandidate); // 候選人挑選
			}, "get BestSolution");

			// 處理最佳解
			timer.apply(() -> {
				if (bestSolution.isPresent()) {
					try {
						// 成功取得最佳解, 轉為Operation輸出
						final List<Operation> operations = new OperationSupplier(bestSolution.get(), shifts).get();
						planedResult.addAll(operations);
						// 記錄每一位工程師最後做的工作, 以便後續的運算利用
						apsResult.setLastOperation(bestSolution.get().programmer, operations.get(operations.size() - 1));
						// 當一個Job已經成功排成任務, 則要從可能性方案中移除, 避免被重複選上
						toRemoveJobs.add(bestSolution.get().job);
					} catch (final OutOfShiftException e) {
						// 超出班表, 這個可能性理論上不能排了, 必須從Metrix中移除, 以避免無窮迴圈(仍需優化)
						log.warn("{} is OutOfShiftException", bestSolution.get());
						toRemoveCandidates.add(bestSolution.get());
					}
				}
			}, "handel Solution");

			// 將已經排成功或不能排的可能性移除
			toRemoveJobs.forEach(matrix::removeJob);
			toRemoveCandidates.forEach(matrix::removeCandidate);
		}

		return apsResult;
	}

}
