package tw.com.softleader.tx;



public interface Say {

	void say();

}
