package tw.com.softleader.demo.ms.gateway.stub;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(name = "beta-rpc")
@RequestMapping("/beta")
public interface BetaRpcStub {

	@GetMapping
	public String get();

}
