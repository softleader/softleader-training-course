package tw.com.softleader.demo.ms.gateway;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import tw.com.softleader.demo.ms.gateway.stub.AlphaRpcStub;
import tw.com.softleader.demo.ms.gateway.stub.BetaRpcStub;

import java.util.HashMap;
import java.util.Map;

@RestController
public class CallController {

	@Autowired
	private AlphaRpcStub alphaRpcStub;

	@Autowired
	private BetaRpcStub betaRpcStub;

	@GetMapping("/call")
	public Map<String, String> call() {

		final HashMap<String, String> result = new HashMap<>();
		result.put("alpha", alphaRpcStub.get());
		result.put("beta", betaRpcStub.get());

		return result;
	}

}
