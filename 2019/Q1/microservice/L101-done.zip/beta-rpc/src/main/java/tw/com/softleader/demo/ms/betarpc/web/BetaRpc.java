package tw.com.softleader.demo.ms.betarpc.web;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.InetAddress;
import java.net.UnknownHostException;

@RestController
public class BetaRpc {

	@GetMapping("/beta")
	public String call() throws UnknownHostException {
		return "beta call " + InetAddress.getLocalHost();
	}

}
