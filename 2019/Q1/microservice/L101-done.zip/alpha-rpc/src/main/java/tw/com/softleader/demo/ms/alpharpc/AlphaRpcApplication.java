package tw.com.softleader.demo.ms.alpharpc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlphaRpcApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlphaRpcApplication.class, args);
	}

}

