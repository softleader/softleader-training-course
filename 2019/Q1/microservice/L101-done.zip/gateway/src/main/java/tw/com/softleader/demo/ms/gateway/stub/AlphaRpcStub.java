package tw.com.softleader.demo.ms.gateway.stub;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.net.UnknownHostException;

@FeignClient(name = "alpha-rpc")
@RequestMapping("/api")
public interface AlphaRpcStub {

	@GetMapping("/alpha")
	public String call() throws UnknownHostException;

}
