package tw.com.softleader.demo.ms.gateway.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tw.com.softleader.demo.ms.gateway.stub.AlphaRpcStub;
import tw.com.softleader.demo.ms.gateway.stub.BetaRpcStub;

import java.net.UnknownHostException;

@RestController
public class DemoController {

	@Autowired
	private AlphaRpcStub alphaRpcStub;

	@Autowired
	private BetaRpcStub betaRpcStub;

	@GetMapping("/call")
	public String call() throws UnknownHostException {
		return alphaRpcStub.call() + " " + betaRpcStub.call();
	}

}
