package tw.com.softleader.demo.ms.gateway.stub;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.net.UnknownHostException;

@FeignClient(name = "beta-rpc")
public interface BetaRpcStub {

	@GetMapping("/beta")
	public String call() throws UnknownHostException;

}
