package com.example.sso.demo;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
public class IndexController {

  @RequestMapping("/index/{name}")
  @ResponseBody
  public String index(HttpServletRequest req,@PathVariable String name) {
    req.getSession().setAttribute("name", name);
    return "hello world " + name;
  }

  @RequestMapping("/setSession/{param}")
  @ResponseBody
  public String TestSession(HttpServletRequest req, HttpServletResponse resp, @PathVariable String param){
    req.getSession().setAttribute("param", param);
    String a = (String) req.getSession().getAttribute("param");
    String b = (String) req.getSession().getAttribute("name");
    return "8181 => HI ~ " + b + " 你key的值為 " + a + " : SessionId為" + req.getSession().getId();
  }

}
