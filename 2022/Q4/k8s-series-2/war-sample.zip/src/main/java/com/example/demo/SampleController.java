package com.example.demo;

import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.net.InetAddress;

@RestController
public class SampleController {

  @Value("${app.service.name}")
  String serviceName;

  @Value("${app.second.service.name}")
  String secondServiceName;

  @SneakyThrows
  @GetMapping
  public String hello() {
    return "hello " + serviceName + " " + InetAddress.getLocalHost().getHostName();
  }

  @SneakyThrows
  @GetMapping("/hello-2")
  public String hello2() {
    var restTemplate = new RestTemplate();
    return restTemplate.getForObject("http://" + secondServiceName + "/", String.class);
  }

}
