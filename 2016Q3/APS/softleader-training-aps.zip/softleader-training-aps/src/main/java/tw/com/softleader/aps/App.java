package tw.com.softleader.aps;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import tw.com.softleader.aps.json.ToGanttSourceService;
import tw.com.softleader.aps.model.ApsResult;
import tw.com.softleader.aps.model.Job;
import tw.com.softleader.aps.model.Programmer;
import tw.com.softleader.aps.service.JobService;
import tw.com.softleader.aps.service.OperationService;
import tw.com.softleader.aps.service.PlanService;
import tw.com.softleader.aps.service.ProgrammerService;

@Slf4j
public class App {

	public static final LocalDateTime startTime = LocalDateTime.parse("2016-08-01T09:30");

	public static ProgrammerService programmerService = new ProgrammerService();
	public static JobService jobService = new JobService();

	public static PlanService planService = new PlanService();
	public static ToGanttSourceService toGanttSourceService = new ToGanttSourceService();

	public static void main(final String[] args) throws FileNotFoundException, IOException {

		// 取得所有可工作的工程師
		final List<Programmer> programmers = programmerService.getAllProgrammers();
		// 取得工作
		final List<Job> jobs = jobService.getSomeJobs();

		log.debug("================All Programmers================");
		programmers.forEach(System.out::println);
		System.out.println();
		log.debug("================All Jobs================");
		jobs.forEach(System.out::println);

		System.out.println();

		// 進行工作排程規劃
		log.info("================Strat Plan================");
		final ApsResult apsResult = planService.plan(startTime, programmers, jobs);
		log.info("================Finished Plan================");

		log.info("================Planed Result================");
		OperationService.print(apsResult.getOperations());

		System.out.println();
		log.info("================Planed Info================");
		apsResult.getTimer().show();
		log.info("Metrix Size: {}", apsResult.getMatrixSize());
		log.info("Planed Operations: {}", apsResult.getOperations().size());

//		toGanttSourceService.writeJson(apsResult.getOperations());

	}

}
