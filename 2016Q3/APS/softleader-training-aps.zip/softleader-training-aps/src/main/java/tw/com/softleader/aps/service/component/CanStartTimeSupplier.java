package tw.com.softleader.aps.service.component;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

import tw.com.softleader.aps.model.ApsCandidate;
import tw.com.softleader.aps.model.ApsResult;
import tw.com.softleader.aps.model.Job;
import tw.com.softleader.aps.model.Operation;
import tw.com.softleader.commons.collect.Lists;

/**
 * 判斷候選人可以使用的開始時間
 *
 * @author Rhys
 */
public class CanStartTimeSupplier implements Supplier<LocalDateTime> {

	private final ApsResult apsResult;
	private final ApsCandidate candidate;
	private final Map<Job, List<Operation>> jobOperations;

	public CanStartTimeSupplier(final ApsCandidate candidate, final Map<Job, List<Operation>> jobOperations, final ApsResult apsResult) {
		this.candidate = candidate;
		this.jobOperations = jobOperations;
		this.apsResult = apsResult;
	}

	@Override
	public LocalDateTime get() {
		final List<LocalDateTime> possibleTime = Lists.newArrayList();

		// 計算起始時間
		possibleTime.add(apsResult.getStartTime());
		// 前一工作結束時間
		preJobFinishTime().ifPresent(possibleTime::add);
		// 此工程師最後一個工作結束時間
		programmerLastFinishTime().ifPresent(possibleTime::add);

		return possibleTime.stream().max(Comparator.naturalOrder()).orElse(null);
	}

	// 前一工作結束時間
	private Optional<LocalDateTime> preJobFinishTime() {
		// 從已經排完的Operation裡面找到前一份工作的結束時間
		if (candidate.job.getPreviousJob() != null && jobOperations.containsKey(candidate.job.getPreviousJob())) {
			return jobOperations.get(candidate.job.getPreviousJob()).stream()
					.map(Operation::getFinishedTime)
					.max(Comparator.naturalOrder());
		} else {
			return Optional.empty();
		}
	}

	// 或工程師的最後一份工作的結束時間
	private Optional<LocalDateTime> programmerLastFinishTime() {
		return apsResult.getLastOperation(candidate.programmer).map(o -> o.getFinishedTime());
	}

}
