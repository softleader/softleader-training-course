package tw.com.softleader.aps.json;

import java.time.ZoneOffset;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import tw.com.softleader.aps.model.Operation;

@Getter
@Setter
public class GanttDetailModel {

	@JsonProperty("from")
	private String from;

	@JsonProperty("to")
	private String to;

	@JsonProperty("label")
	private String label;

	@JsonProperty("customClass")
	private String customClass;

	public GanttDetailModel(final Operation operation) {
		this.from = "/Date(" + operation.getStartedTime().toInstant(ZoneOffset.ofHours(8)).toEpochMilli() + ")/";
		this.to = "/Date(" + operation.getFinishedTime().toInstant(ZoneOffset.ofHours(8)).toEpochMilli() + ")/";
		this.label = operation.getJob().getName();
		final int color = Integer.valueOf(operation.getJob().getProjectName().substring(3)) % 4;

		switch (color) {
			case 0:
				customClass = "ganttRed";
				break;
			case 1:
				customClass = "ganttGreen";
				break;
			case 2:
				customClass = "ganttBlue";
				break;
			case 3:
				customClass = "ganttOrange";
				break;
			default:
				break;
		}
	}

}
