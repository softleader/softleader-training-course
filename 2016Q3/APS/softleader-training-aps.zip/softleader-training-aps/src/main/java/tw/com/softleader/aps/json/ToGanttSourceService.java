package tw.com.softleader.aps.json;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;

import tw.com.softleader.aps.model.Operation;
import tw.com.softleader.aps.model.Programmer;
import tw.com.softleader.commons.collect.Lists;

/**
 * 為了能將規劃的結果圖形化，用來轉成Json的Service
 * @author Rhys
 */
public class ToGanttSourceService {

	ObjectMapper objectMapper = new ObjectMapper();

	public void writeJson(final List<Operation> source) throws FileNotFoundException, IOException {

		final Map<Programmer, List<Operation>> groupedOperations = source.stream()
				.collect(
					Collectors.groupingBy(Operation::getProgrammer, () -> new TreeMap<>(Comparator.comparing(Programmer::getName)), Collectors.toList())
				);
		final List<GanttModel> models = Lists.newArrayList();
		groupedOperations.forEach((programmer, operations) -> {
			models.add(new GanttModel(programmer, operations));
		});

		final File json = new File("C:/Users/Softleader/Desktop/GanttTest/data.json");
		objectMapper.writeValue(new FileOutputStream(json), models);
	}

}
