package tw.com.softleader.aps.service;

import java.util.List;

import tw.com.softleader.aps.model.Job;
import tw.com.softleader.aps.model.JobType;
import tw.com.softleader.commons.collect.Lists;
import tw.com.softleader.util.StringUtils;

/**
 * 用來產生工作的Service
 * 這個系統原則上可以處理多個前置任務的情況
 * 但為了簡化假資料的產生, 仍以單一前置任務的方式產生
 *
 * @author Rhys
 */
public class JobService {

	// 取得一些專案
	public List<Job> getSomeJobs() {
		final List<Job> jobs = Lists.newArrayList();
		for (int i = 1; i <= 100; i++) {
			jobs.addAll(this.randomJobs("Job" + i, 0, Lists.newArrayList()));
		}
		return jobs;
	}

	// 隨機產生一個專案
	private List<Job> randomJobs(final String jobName, Integer jobSeq, final List<Job> allJob) {
		jobSeq += 1;
		if (allJob.isEmpty()) {
			allJob.add(randomJob(jobName, jobSeq, null));
			return randomJobs(jobName, jobSeq, allJob);
		} else if ((Math.random() * 100) > 10) {
			allJob.add(randomJob(jobName, jobSeq, allJob.get(allJob.size() - 1)));
			return randomJobs(jobName, jobSeq, allJob);
		} else {
			return allJob;
		}
	}


	// 隨機產生一個Job, 並排在previousJob之後
	// JobName範例: Job1-001, Job1-002, Job1-003, Job2-001...
	private Job randomJob(final String jobName, final Integer jobSeq, final Job previousJob) {
		final JobType jobType = JobType.values()[(int)(Math.random() * 3)];
		final String jobFullName = jobName + "-" + StringUtils.leftPad(Integer.toString(jobSeq), 3, '0');
		final int quantity = (int)(Math.random() * 80) + 20;
		return new Job(jobType, jobFullName, quantity, previousJob);
	}

}
