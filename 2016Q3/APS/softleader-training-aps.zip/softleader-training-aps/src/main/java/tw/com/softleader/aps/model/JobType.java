package tw.com.softleader.aps.model;

/**
 * 工作類型
 *
 * @author Rhys
 */
public enum JobType {

	develop, // 開發
	mainten, // 維運
	debug, // 除錯
	test // 測試

}
