package tw.com.softleader.aps.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

/**
 * 任務, 記錄某Programmer進行某Job的情況
 * 由於一個工作可能因為沒辦法在一個班表內完成而被切分成多個任務
 * 因此本Operation額外紀錄了Percent來表現本Operation占了Job多少百分比
 *
 * @author Rhys
 */
@Getter
@Setter
public class Operation {

	// 工程師
	private final Programmer programmer;

	// 工作
	private final Job job;

	// 完成百分比
	private BigDecimal percent;

	// 工作時間
	private final long workMinute;

	// 工作開始時間
	private LocalDateTime startedTime;

	// 工作結束時間
	private LocalDateTime finishedTime;

	/**
	 * 將工作指派給某工程師
	 * 此處會檢查該工作是否已經被執行
	 * @param programmer
	 * @param job
	 * @param startedTime
	 * @param finishedTime
	 */
	public Operation(final Programmer programmer, final Job job, final LocalDateTime startedTime, final LocalDateTime finishedTime) {
		super();
		this.programmer = programmer;
		this.job = job;
		this.startedTime = startedTime;
		this.finishedTime = finishedTime;
		this.workMinute = Duration.between(startedTime, finishedTime).toMinutes();
	}

	@Override
	public String toString() {
		return "(" + programmer.getName() + ")" + job.toString() + "(" + (percent.multiply(BigDecimal.valueOf(100)).setScale(2, RoundingMode.HALF_UP)) + ") " + startedTime + "~" + finishedTime;
	}

}
