package tw.com.softleader.aps.model;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import lombok.Getter;
import tw.com.softleader.aps.ApsTimer;
import tw.com.softleader.commons.collect.Maps;

/**
 * 用來記錄規劃排程過程中的的統計資訊
 *
 * @author Rhys
 */
@Getter
public class ApsResult {

	private LocalDateTime startTime; // 計算起始時間
	private ApsMatrix matrix; // 可能性矩陣
	private int matrixSize; // 矩陣大小
	private List<Shift> shifts; // 班表
	private List<Operation> operations; // 任務
	private Map<Programmer, Operation> lastOperationOfProgrammer; // 工程師最後執行的工作
	private ApsTimer timer;

	public ApsResult(final ApsTimer timer, final LocalDateTime startTime, final ApsMatrix matrix, final int matrixSize, final List<Shift> shifts, final List<Operation> operations) {
		super();
		this.timer = timer;
		this.startTime = startTime;
		this.matrix = matrix;
		this.matrixSize = matrixSize;
		this.shifts = shifts;
		this.operations = operations;
		this.lastOperationOfProgrammer = Maps.newHashMap();
	}

	public void setLastOperation(final Programmer programmer, final Operation operation) {
		lastOperationOfProgrammer.put(programmer, operation);
	}

	public Optional<Operation> getLastOperation(final Programmer programmer) {
		if (lastOperationOfProgrammer.containsKey(programmer)) {
			return Optional.ofNullable(lastOperationOfProgrammer.get(programmer));
		} else {
			return Optional.empty();
		}
	}

}
