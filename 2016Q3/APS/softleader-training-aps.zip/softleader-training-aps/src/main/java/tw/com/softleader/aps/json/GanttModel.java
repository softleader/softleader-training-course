package tw.com.softleader.aps.json;

import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import tw.com.softleader.aps.model.Operation;
import tw.com.softleader.aps.model.Programmer;

@Getter
@Setter
public class GanttModel {

	@JsonProperty("name")
	private String name;

	@JsonProperty("desc")
	private String desc;

	@JsonProperty("values")
	private List<GanttDetailModel> values;

	public GanttModel(final Programmer programmer, final List<Operation> operations) {
		this.name = programmer.getJobType().toString();
		this.desc = "Programmer " + programmer.getName();
		values = operations.stream().map(GanttDetailModel::new).collect(Collectors.toList());
	}

}
