package tw.com.softleader.example.demo;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

import tw.com.softleader.kapok.core.KapokVersion;
import tw.com.softleader.kapok.test.KapokTest;

@KapokTest
@Timeout(1)
class DemoApplicationTests {

  @Test
  void contextLoads() {
    Assertions.assertThat(KapokVersion.getVersion()).isNotBlank();
  }

}
