package tw.com.softleader.example.demo;

import java.io.IOException;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import tw.com.softleader.kapok.core.KapokApplication;
import tw.com.softleader.kapok.core.KapokBootstrap;

@KapokBootstrap
class DemoApplication {

  public static void main(String[] args) {
    KapokApplication.run(DemoApplication.class, args);
  }

}

@RestController
@RequiredArgsConstructor
@RequestMapping("/files")
class FileController {

  @Value("${root}")
  final String root;

  @PostMapping("/{name}")
  boolean createFile(@PathVariable("name") String name) throws IOException {
    return Paths.get(root).resolve(name).toFile().createNewFile();
  }

}
