package tw.com.softleader.example.oom;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import tw.com.softleader.kapok.core.KapokApplication;
import tw.com.softleader.kapok.core.KapokBootstrap;

@KapokBootstrap
class OomApplication {

  public static void main(String[] args) {
    KapokApplication.run(OomApplication.class, args);
  }

  @Bean
  OOMSimulation oomSimulation() {
    return new OOMSimulation();
  }
}


class OOMSimulation implements ApplicationRunner {

  @Override
  public void run(ApplicationArguments args) throws InterruptedException {
    var delay = Optional.ofNullable(System.getenv("DELAY"))
      .map(Integer::parseInt)
      .orElse(0);

    System.out.println("delay: " + delay);

    List<byte[]> list = new ArrayList<>();

    while (true) {
      byte[] array = new byte[1024 * 1024 * 10]; // 每次迴圈增加 arraySize MB 的陣列
      list.add(array);

      long maxMemory = Runtime.getRuntime().maxMemory();
      long totalMemory = Runtime.getRuntime().totalMemory();
      long freeMemory = Runtime.getRuntime().freeMemory();

      System.out.printf("JVM 記憶體上限: %s, 總記憶體: %s, 可用記憶體: %s%n",
        formatMemorySize(maxMemory),
        formatMemorySize(totalMemory),
        formatMemorySize(freeMemory));

      Thread.sleep(delay);
    }
  }

  private String formatMemorySize(long size) {
    if (size <= 0) {
      return "0";
    }

    final String[] units = {"B", "KB", "MB", "GB", "TB"};
    int digitGroups = (int) (Math.log10(size) / Math.log10(1024));

    return String.format("%.1f %s", size / Math.pow(1024, digitGroups), units[digitGroups]);
  }
}
