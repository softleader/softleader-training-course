package tw.com.softleader.example.oom;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import tw.com.softleader.kapok.test.KapokTest;

@KapokTest
@Timeout(1)
class OomApplicationTests {

	@Test
	@Disabled
	void contextLoads() {
	}

}
