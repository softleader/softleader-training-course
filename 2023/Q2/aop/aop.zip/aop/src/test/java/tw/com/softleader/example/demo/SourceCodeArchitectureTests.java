package tw.com.softleader.example.demo;

import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.junit.ArchTests;
import com.tngtech.archunit.lang.ArchRule;

@AnalyzeClasses(packagesOf = tw.com.softleader.example.demo.SourceCodeArchitectureTests.class, importOptions = {
  com.tngtech.archunit.core.importer.ImportOption.DoNotIncludeTests.class,
  com.tngtech.archunit.core.importer.ImportOption.DoNotIncludeJars.class})
class SourceCodeArchitectureTests {

  @ArchTest
  static final ArchTests general_rules = com.tngtech.archunit.junit.ArchTests.in(
    tw.com.softleader.kapok.test.archunit.GeneralRules.GeneralRulesSuite.class);

  @ArchTest
  static final ArchTests naming_rules = com.tngtech.archunit.junit.ArchTests.in(
    tw.com.softleader.kapok.test.archunit.NamingRule.NamingRuleSuite.class);

  @ArchTest
  static final ArchRule methods_should_have_at_most_60_lines = com.tngtech.archunit.lang.syntax.ArchRuleDefinition.methods()
    .that(tw.com.softleader.kapok.test.archunit.JavaMethodsThat.areNotLombokBuilderDefaults()).and()
    .areDeclaredInClassesThat(
      tw.com.softleader.kapok.test.archunit.JavaClassesThat.areNotLombokBuilders()).and()
    .areDeclaredInClassesThat(
      tw.com.softleader.kapok.test.archunit.JavaClassesThat.areNotMapStructMapperImplementations())
    .should(tw.com.softleader.kapok.test.archunit.JavaMethodsShould.haveLinesAtMost(60)).because(
      "you should avoid long method that contains too many lines of code, see more: https://refactoring.guru/smells/long-method");

  @ArchTest
  static final ArchRule methods_should_have_at_most_7_parameters = com.tngtech.archunit.lang.syntax.ArchRuleDefinition.methods()
    .that(tw.com.softleader.kapok.test.archunit.JavaMethodsThat.areNotLombokBuilderDefaults()).and()
    .areDeclaredInClassesThat(
      tw.com.softleader.kapok.test.archunit.JavaClassesThat.areNotLombokBuilders()).and()
    .areDeclaredInClassesThat(
      tw.com.softleader.kapok.test.archunit.JavaClassesThat.areNotMapStructMapperImplementations())
    .should(tw.com.softleader.kapok.test.archunit.JavaMethodsShould.haveParametersAtMost(7))
    .because(
      "it’s hard to understand such lists, which become contradictory and hard to use as they grow longer, see more: https://refactoring.guru/smells/long-parameter-list");

  @ArchTest
  static final ArchRule constructors_should_have_at_most_30_arguments = com.tngtech.archunit.lang.syntax.ArchRuleDefinition.constructors()
    .that().areDeclaredInClassesThat(
      tw.com.softleader.kapok.test.archunit.JavaClassesThat.areNotLombokBuilders()).and()
    .areDeclaredInClassesThat(
      tw.com.softleader.kapok.test.archunit.JavaClassesThat.areNotMapStructMapperImplementations())
    .should(tw.com.softleader.kapok.test.archunit.JavaConstructorsShould.haveArgumentsAtMost(30))
    .because(
      "classes shouldn't have too many responsibilities, see more: https://refactoring.guru/smells/large-class");

}
