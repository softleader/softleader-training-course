package tw.com.softleader.example.demo;

import lombok.AllArgsConstructor;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import tw.com.softleader.kapok.core.KapokApplication;
import tw.com.softleader.kapok.core.KapokBootstrap;

@KapokBootstrap
class AopApplication {

  public static void main(String[] args) {
    var bean = KapokApplication.run(AopApplication.class, args)
      .getBean(MyService.class);
    bean.doSomething();
    bean.selectDb();

//    var greeting = new Greeting();

    //Greeting greeting = new Greeting2();
    //System.out.println("sake hands..");

    // Say greeting = new Greeting3(new Greeting());
    // greeting.say();
    //System.out.println("bye");

    // sake hands
    // hello
    // bye

  }

}

@Service
class MyRepository {

  public void selectDb() { // 2
    try {
    System.out.println("select from ...");
    } catch (Exception e) {
      // ignore
    }
  }
}

@AllArgsConstructor
@Service
class MyService {

  // BeanFactory beanFactory;
  MyRepository repository;

  public void doSomething() { // 1 start tx
    // beanFactory.getBean(MyService.class).selectDb();
    // selectDb();


      repository.selectDb();

    System.out.println("...");
  }

  public void selectDb() {
    System.out.println("select from ...");
  }
}

@Component
@Aspect
class MyAspect {

  @Around("@within(org.springframework.stereotype.Service) || @annotation(org.springframework.stereotype.Service)")
  Object around(ProceedingJoinPoint joinPoint) throws Throwable {
    try {
      System.out.println("begin transaction");
      var proceed = joinPoint.proceed();
      System.out.println("commit transaction");
      return proceed;
    } catch (Exception e) {
      System.out.println("註記在 thread: rollback transaction");
      throw e;
    }
  }
}

interface Say {

  void say();
}

class Greeting implements Say {

  public void say() {
    System.out.println("Hello!");
    hello();
  }

  public void hello() {
    System.out.println("Hello again");
  }
}

// cglib -> proxy
class Greeting2 extends Greeting {

  @Override
  public void say() {
    System.out.println("sake hands..");
    super.say();
    System.out.println("bye");
  }
}

// jdk -> proxy
@AllArgsConstructor
class Greeting3 implements Say {

  Say say;

  @Override
  public void say() {
    System.out.println("sake hands..");
    say.say();
    System.out.println("bye");
  }
}
