package tw.com.softleader.example.demo;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import tw.com.softleader.example.demo.jpa.EmployeeDao;
import tw.com.softleader.example.demo.jpa.EmployeeEntity;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class EmployeeService {

  final EmployeeDao employeeDao;

  public Page<EmployeeEntity> findAll(Specification<EmployeeEntity> spec, Pageable pageable) {
    return employeeDao.findAll(spec, pageable);
  }

  public Optional<EmployeeEntity> findByName(String name) {
    return employeeDao.findByName(name);
  }

}
