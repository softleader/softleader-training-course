package tw.com.softleader.example.demo.rules;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RuleExecutor {

  final List<RuleInterface> rules;

  public RuleExecutor(List<RuleInterface> rules) {
    this.rules = rules;
  }

  public List<String> executeTest(String factor) {
    return rules.stream().filter(r -> r.test(factor))
      .map(RuleInterface::returnCode)
      .toList();
  }

}
