package tw.com.softleader.example.demo;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.webjars.NotFoundException;
import tw.com.softleader.example.demo.jpa.EmployeeEntity;

import javax.persistence.criteria.Predicate;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;
import java.util.stream.Stream;

@RestController
@RequiredArgsConstructor
@RequestMapping("/emp")
public class EmployeeController {

  final EmployeeService employeeService;

  @GetMapping
  public Page<EmployeeEntity> query(
    String nameLike,
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dutyDateFrom,
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dutyDateTo,
    BigDecimal salaryGe,
    Pageable pageable) {

    var spec = Specification.<EmployeeEntity>where((root, query, criteriaBuilder) -> {

      var predicates = Stream.of(
          Optional.ofNullable(nameLike).map(v -> criteriaBuilder.like(root.get("name"), "%" + v + "%")),
          Optional.ofNullable(dutyDateFrom).map(v -> criteriaBuilder.greaterThanOrEqualTo(root.get("dutyDate"), v)),
          Optional.ofNullable(dutyDateTo).map(v -> criteriaBuilder.lessThanOrEqualTo(root.get("dutyDate"), v)),
          Optional.ofNullable(salaryGe).map(v -> criteriaBuilder.greaterThanOrEqualTo(root.get("salary"), v)))
        .filter(Optional::isPresent)
        .map(Optional::get)
        .toArray(Predicate[]::new);

      return criteriaBuilder.and(predicates);
    });

    return employeeService.findAll(spec, pageable);
  }

  @GetMapping("/{name}")
  public EmployeeEntity query(@PathVariable String name) {
    return employeeService.findByName(name)
      .orElseThrow(() -> new NotFoundException("name 不存在"));
  }

}
