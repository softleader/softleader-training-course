package tw.com.softleader.example.demo.jpa;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@Entity
@Table(name = "EMP", indexes = {
  @Index(columnList = "name", unique = true),
  @Index(columnList = "dutyDate")
})
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeEntity extends GenericEntity {

  @Column(length = 50)
  String name;

  @Column
  LocalDate dutyDate;

  @Column(precision = 15, scale = 2)
  BigDecimal salary;

}
