package tw.com.softleader.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import tw.com.softleader.example.demo.rules.RuleExecutor;

import javax.annotation.PostConstruct;

@Service
public class ApplicationStartedListener {
  static final Logger log = LoggerFactory.getLogger(ApplicationStartedListener.class);

  final RuleExecutor ruleExecutor;

  public ApplicationStartedListener(RuleExecutor ruleExecutor) {
    this.ruleExecutor = ruleExecutor;
  }

  @PostConstruct
  public void init() {
    var factor = "1";
    log.warn("init ruleExecutor executeTest factor: {}", factor);
    var strings = ruleExecutor.executeTest(factor);
    log.warn("executeTest result: {}", String.join(",", strings));
  }

}
