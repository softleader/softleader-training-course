package tw.com.softleader.example.demo.rules.components;

import org.springframework.stereotype.Component;
import tw.com.softleader.example.demo.rules.RuleInterface;

@Component
public class Rule1 implements RuleInterface {
  @Override public String returnCode() {
    return "RULE_1";
  }

  @Override public boolean test(String factor) {
    return "1".equals(factor);
  }
}
