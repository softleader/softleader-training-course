package tw.com.softleader.example.demo.web;

public class SampleRequest {

  String name;
  String greetingWord = "hello";

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getGreetingWord() {
    return greetingWord;
  }

  public void setGreetingWord(String greetingWord) {
    this.greetingWord = greetingWord;
  }
}
