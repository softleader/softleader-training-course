package tw.com.softleader.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import tw.com.softleader.example.demo.jpa.EmployeeDao;
import tw.com.softleader.example.demo.jpa.EmployeeEntity;
import tw.com.softleader.example.demo.rules.components.Rule3;
import tw.com.softleader.kapok.core.KapokApplication;
import tw.com.softleader.kapok.core.KapokBootstrap;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@KapokBootstrap
@EnableWebMvc
class DemoApplication  {

  public static void main(String[] args) {
    KapokApplication.run(DemoApplication.class, args);
  }

  @Bean
  public Rule3 rule3() {
    return new Rule3("1");
  }

  @Autowired EmployeeDao employeeDao;

  @PostConstruct
  public void dataInit() {
    employeeDao.saveAll(List.of(
      EmployeeEntity.builder().name("Rhys")
        .dutyDate(LocalDate.of(2023, 3, 31))
        .salary(new BigDecimal("1234")).build()
    ));
  }

}
