package tw.com.softleader.example.accesscontrol;

import lombok.RequiredArgsConstructor;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import tw.com.softleader.kapok.core.KapokApplication;
import tw.com.softleader.kapok.core.KapokBootstrap;

@EnableFeignClients
@KapokBootstrap
class AccesscontrolApplication {

	public static void main(String[] args) {
		KapokApplication.run(AccesscontrolApplication.class, args);
	}

}

@FeignClient(name = "internal", url = "http://localhost:8080")
interface InternalClient {

  @GetMapping("/internal")
  String name();
}


@RestController
@RequiredArgsConstructor
class HelloController {

  final InternalClient client;

//  @PreAuthorize("hasRole('GI_SALES_LEADER') or hasAuthority('CMN_AGENTORG_EDIT')")
  @PreAuthorize("hasPermission('*_AGENTORG', 'VIEW,EDIT,CREATE')")
  @GetMapping
  String name() {
    return
      "%s -> %s%n%n%s".formatted(
        SecurityContextHolder.getContext().getAuthentication().getName(),
        SecurityContextHolder.getContext().getAuthentication().getAuthorities(),
        client.name()
      )

      ;
  }
}

@RestController
class InternalController {

  @PreAuthorize("hasRole('sudo')")
  @GetMapping("/internal")
  String name() {
    return
      "%s -> %s".formatted(
        SecurityContextHolder.getContext().getAuthentication().getName(),
        SecurityContextHolder.getContext().getAuthentication().getAuthorities()
      )

      ;
  }
}
