package tw.com.softleader.example.demo.web;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.stream.Collectors;

@RestController
public class SampleController {

  @GetMapping("/hello1")
  public String hello1(@RequestParam String[] name) {
    // 吃 query string
    return Arrays.stream(name).map(n -> "hello " + n).collect(Collectors.joining("\n"));
  }

  @PostMapping("/hello2")
  public String hello2(@RequestBody SampleRequest request) {
    // 吃 request body (json/xml)
    return request.getGreetingWord() + " " + request.getName();
  }

  @PostMapping("/hello3")
  public String hello3(@RequestParam String name, @RequestParam String greetingWord) {
    // 吃 query string & request body (form)
    return greetingWord + " " + name;
  }

  @PostMapping("/hello-error")
  public String hello4() {
    // response 500
    throw new UnsupportedOperationException();
  }

}
