package tw.com.softleader.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import tw.com.softleader.example.demo.rules.components.Rule3;
import tw.com.softleader.kapok.core.KapokApplication;
import tw.com.softleader.kapok.core.KapokBootstrap;

@KapokBootstrap
@EnableWebMvc
class DemoApplication {

  public static void main(String[] args) {
    KapokApplication.run(DemoApplication.class, args);
  }

  @Bean
  public Rule3 rule3() {
    return new Rule3("1");
  }

}
