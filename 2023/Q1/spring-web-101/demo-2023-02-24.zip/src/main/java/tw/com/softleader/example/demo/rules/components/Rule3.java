package tw.com.softleader.example.demo.rules.components;

import org.springframework.stereotype.Component;
import tw.com.softleader.example.demo.rules.RuleInterface;

@Component
public class Rule3 implements RuleInterface {

  private String target;

  public Rule3() {
    this("3");
  }

  public Rule3(String target) {
    this.target = target;
  }

  @Override public String returnCode() {
    return "RULE_3";
  }

  @Override public boolean test(String factor) {
    return target.equals(factor);
  }
}
