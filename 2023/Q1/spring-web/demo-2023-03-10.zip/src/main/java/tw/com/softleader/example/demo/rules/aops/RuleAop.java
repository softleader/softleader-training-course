package tw.com.softleader.example.demo.rules.aops;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class RuleAop {
  static final Logger log = LoggerFactory.getLogger(RuleAop.class);

  @Pointcut("execution(* tw.com.softleader.example.demo.rules.RuleInterface..test(..))")
  public void pointcut() {
  }

  @Before("pointcut()")
  public void before(JoinPoint joinPoint) {
    log.info("Executing {} with factor: {}", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getArgs());
  }

}
