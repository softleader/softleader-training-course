package tw.com.softleader.example.demo.rules;

public interface RuleInterface {

  String returnCode();

  boolean test(String factor);

}
