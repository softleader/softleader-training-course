# demo

> Demo project

This project uses Kapok. If you want to learn more about Kapok, please visit: https://github.com/softleader/kapok/ .

## Running the application

You can run your application using:

```shell script
./mvnw spring-boot:run
```

## Packaging the container image

Build your optimized container image with:

```shell script
./mvnw package jib:build
```

Build your image directly to a Docker daemon:

```shell script
./mvnw package jib:dockerBuild
```

You can build and save your image to disk as a tarball with:

```shell script
./mvnw package jib:buildTar
```
