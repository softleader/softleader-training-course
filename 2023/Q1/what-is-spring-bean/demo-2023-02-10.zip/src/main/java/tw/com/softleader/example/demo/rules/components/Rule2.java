package tw.com.softleader.example.demo.rules.components;

import org.springframework.stereotype.Component;
import tw.com.softleader.example.demo.rules.RuleInterface;

@Component
public class Rule2 implements RuleInterface {
  @Override public String returnCode() {
    return "RULE_2";
  }

  @Override public boolean test(String factor) {
    return "2".equals(factor);
  }
}
